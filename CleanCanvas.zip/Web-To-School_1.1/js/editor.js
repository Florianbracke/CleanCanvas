wp.domReady( () => {

	wp.blocks.registerBlockStyle( 'core/button', [
		{
			name: 'onderlijnen',
			label: 'OnderLijnen',
		},
	]);

} );
